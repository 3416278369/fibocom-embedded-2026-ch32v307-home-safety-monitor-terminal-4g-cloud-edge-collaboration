#ifndef __CALL_H
#define __CALL_H

#include "ch32v30x.h"
#include <rtthread.h>
#include <rthw.h>
#include "drivers/pin.h"
#include "task.h"
#include "math.h"
#include <stdio.h>
#include <string.h>
#include <rtdevice.h>
//
#include "usart3.h"
#include "usart4.h"
#include "usart5.h"
#include "usart6.h"
#include "i2c1.h"
#include "gpio.h"
#include "aht20.h"
#include "adc1_read.h"
#include "adc1.h"
#include "hearrate.h"
#include "hearrate_math.h"
#include "gtim3.h"
#include "tim6.h"
#include "my_app.h"
#include "l610_init.h"
#include "gbk_utf8/gbk2utf8.h"



extern uint8_t yuying;//语音输出id
extern uint8_t dianhua;//电话拨打联系人
extern uint8_t dinwei;//是否获取定位
extern uint8_t huawunyun;//
extern uint8_t rtc;//获取时间
extern uint8_t lianxiren_0[12];
extern uint8_t lianxiren_1[12];//联系人
extern uint8_t lianxiren_2[12];
extern uint8_t yuying_flag[5];//语音标志
extern uint8_t dianhua_flag2; //电话拨打完成标志位
extern uint8_t hear;

extern volatile uint8_t relay_1;
extern volatile uint8_t relay_2;
extern volatile uint8_t relay_3;
extern  uint8_t hongwai_flag;

extern uint8_t contron;

extern float temp;
extern uint8_t yuzhi[5];//传感器参考值
extern volatile uint8_t duoji_flag;


extern volatile uint8_t shuaidao[4];//摔倒数据
extern volatile uint8_t lianjiecg;

#endif
/*
rt_kprintf;
rt_thread_mdelay,ms

*/