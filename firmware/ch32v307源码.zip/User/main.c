#include "call.h"

int main(void)
{
    //rt_kprintf("\r\n MCU: CH32V307\r\n");
    SystemCoreClockUpdate();
    //rt_kprintf(" SysClk: %dHz\r\n", SystemCoreClock);
    // rt_kprintf(" ChipID: %08x\r\n", DBGMCU_GetCHIPID());
    // rt_kprintf(" www.wch.cn\r\n");
    
    task_init();
    
    while (1)
    {
        rt_thread_mdelay(500);
    }
}
