#ifndef __TIM6_H
#define __TIM6_H
#include "ch32v30x.h"

void TIM6_Init_1ms(uint16_t ARR,uint16_t PSC);

#endif