#ifndef __GTIM3_H
#define __GTIM3_H


#include "ch32v30x.h"

void PWM_GPIO_Init(void);
void TIM3_PWM_Init(u16 arr, u16 psc);
void SG90_SetAngle(float angle);

#endif