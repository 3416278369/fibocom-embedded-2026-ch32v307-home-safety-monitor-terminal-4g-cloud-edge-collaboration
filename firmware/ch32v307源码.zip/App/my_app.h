#ifndef __MY_APP_H
#define __MY_APP_H

#include "ch32v30x.h"
/* ========== 传感器数据结构体 ========== */
/* 存储所有传感器采集的数据信息 */
typedef struct
{
    float   temperature;    /* 温度 (℃)  */
    float   humidity;       /* 湿度 (%RH) */
    uint8_t light;          /* 光照强度 (0-100%) */
    uint8_t fire;           /* 火焰强度 (0-100%) */
    float   air_quality;    /* 空气质量 (ppm)   */
    uint16_t heart_rate;    /* 心率 (bpm)       */
    uint8_t   spo2;           /* 血氧饱和度 (%)    */
    uint8_t soil;           /*土壤湿度(0-100%)*/
} sensor_data_t;

/* 全局传感器数据结构体声明 */
extern volatile sensor_data_t g_sensor_data;


void app_disp(void *param);
void sensor_read(void *param);
void hr_thread_entry(void *param);
void L610_app(void *param);
#endif
