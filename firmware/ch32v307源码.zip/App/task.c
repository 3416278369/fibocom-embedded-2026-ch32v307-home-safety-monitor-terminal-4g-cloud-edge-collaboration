/**
  * 线程创建流程总结：
  * 
  * 1. 定义线程控制块指针：rt_thread_t led_thread;
  * 2. 编写线程入口函数：void led_thread_entry(void *param) { ... }
  * 3. 调用 rt_thread_create() 动态创建线程
  * 4. 调用 rt_thread_startup() 将线程加入就绪队列
  * 
  * 线程状态转换：
  *   初始态 → 创建态 → 就绪态 → 运行态 → 阻塞态/就绪态 → ...
  * 
  * 优先级说明：
  *   RT-Thread 默认支持 256 级优先级（0-255）
  *   0 为最高优先级，255 为最低优先级
  *   空闲线程（idle）优先级为 255
  * 
  * 栈大小选择：
  *   简单任务：256-512 字节
  *   复杂任务：1024-4096 字节
  *   需要考虑函数调用深度和局部变量大小
  * 线程创建步骤：
  * 1. 定义线程控制块 (rt_thread_t)
  * 2. 编写线程入口函数
  * 3. 调用 rt_thread_create() 创建线程
  * 4. 调用 rt_thread_startup() 启动线程
  */

#include "call.h"

 
 //动态线程控制块指针
rt_thread_t sensor_tread = RT_NULL;
rt_thread_t myapp_thread = RT_NULL;
rt_thread_t l610_thread = RT_NULL;

//静态线程定义
/* 心率检测静态线程资源 */
static rt_uint8_t hr_thread_stack[1024];
static struct rt_thread hr_thread;

static void All_Init(void)
{
    USARTx_CFG();
    UART4_CFG();
    UART5_CFG();
    UART6_CFG();
    atk_aht20_init();

    atk_max30102_init();
    max30102_fir_init();

    ADC1_MultiChannel_Init();
    
    Relay_Init();

    PWM_GPIO_Init();
    //    如果 TIM3 时钟是 72MHz，用下面这一行
    //TIM3_PWM_Init(19999, 71);
    
    //    如果 TIM3 时钟是 144MHz，改用这一行（注释掉上面）
    TIM3_PWM_Init(19999, 143);
    
    TIM6_Init_1ms(143,999);

    l6104g_init();//L610初始化
}


void task_init(void)
{
    /* 初始化硬件资源 */
    All_Init();  // 初始化 LED1（主函数使用）
    
    //sensor_tread，动态创建线程 - rt_thread_create()
    sensor_tread = rt_thread_create("sensor_read",          // 线程名称："sensor_read" 线程名称，用于调试和识别，最大 16 个字符
                                  sensor_read, // 线程入口函数指针
                                  RT_NULL,          // 线程参数：传递给线程的参数（这里为 RT_NULL）
                                  1024,            // 栈大小：1024 字节（浮点运算+深度调用链需要更大栈）
                                  10,              // 优先级：10（中等优先级）线程优先级（0-255，数值越小优先级越高）
                                  10);             // 时间片：10 个 tick，时间片大小（tick 数），用于同优先级线程轮转

    /* 检查线程是否创建成功 */
    if (sensor_tread != RT_NULL){
        /* brief 启动线程 - rt_thread_startup()，
        将创建好的线程加入到系统的就绪队列中，使其成为可被调度器调度的状态。 */
        rt_thread_startup(sensor_tread);
    }


    //app_disp，动态创建线程 - rt_thread_create()
    myapp_thread = rt_thread_create("app_disp",app_disp,RT_NULL,512,7,10);
    if (myapp_thread != RT_NULL){
        rt_thread_startup(myapp_thread);
    }

    //L610_app，动态创建线程 - rt_thread_create()
    l610_thread = rt_thread_create("L610_app",L610_app,RT_NULL,1024,8,10);
    if (l610_thread != RT_NULL){
        rt_thread_startup(l610_thread);
    }

    //hearrate，静态创建线程 - rt_thread_init()
    rt_thread_init(&hr_thread, "hearrate", hr_thread_entry, RT_NULL,
                   hr_thread_stack, sizeof(hr_thread_stack),
                   11, 10);
    rt_thread_startup(&hr_thread);
}
