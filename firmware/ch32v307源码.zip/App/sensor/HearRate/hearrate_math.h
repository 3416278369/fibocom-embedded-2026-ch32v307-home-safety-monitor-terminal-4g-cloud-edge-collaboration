#ifndef _HEARRATE_MATH_H
#define _HEARRATE_MATH_H

#include "ch32v30x.h"

#define FIR_NUM_TAPS             29

typedef struct {
    float *pCoeffs;
    float *pState;
    uint16_t numTaps;
} fir_instance_f32;

/******************************************************************************************/
/* 外部接口函数*/

void max30102_fir_init(void);
void ir_max30102_fir(float *input, float *output);
void red_max30102_fir(float *input, float *output);

#endif
