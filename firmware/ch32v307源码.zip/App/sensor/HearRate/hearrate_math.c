#include "call.h"

#define BLOCK_SIZE           1

static uint32_t blockSize = BLOCK_SIZE;
static fir_instance_f32 S_ir, S_red;
static float firStateF32_ir[BLOCK_SIZE + FIR_NUM_TAPS - 1];
static float firStateF32_red[BLOCK_SIZE + FIR_NUM_TAPS - 1];

const float firCoeffs32LP[FIR_NUM_TAPS] =
{
    -0.001542701735, -0.002211477375, -0.003286228748, -0.00442651147, -0.004758632276,
    -0.003007677384, 0.002192312852, 0.01188309677, 0.02637642808, 0.04498152807,
    0.06596207619, 0.0867607221, 0.1044560149, 0.1163498312, 0.1205424443,
    0.1163498312, 0.1044560149, 0.0867607221, 0.06596207619, 0.04498152807,
    0.02637642808, 0.01188309677, 0.002192312852, -0.003007677384, -0.004758632276,
    -0.00442651147, -0.003286228748, -0.002211477375, -0.001542701735
};

static void fir_init_f32(fir_instance_f32 *S, uint16_t numTaps, float *pCoeffs, float *pState, uint32_t blockSize)
{
    S->numTaps = numTaps;
    S->pCoeffs = pCoeffs;
    S->pState = pState;
    uint16_t i;
    for (i = 0; i < numTaps + blockSize - 1; i++)
    {
        pState[i] = 0.0f;
    }
}

static void fir_f32(const fir_instance_f32 *S, const float *pSrc, float *pDst, uint32_t blockSize)
{
    const float *pCoeffs = S->pCoeffs;
    float *pState = S->pState;
    uint16_t numTaps = S->numTaps;
    uint32_t i, j;

    for (i = 0; i < blockSize; i++)
    {
        for (j = numTaps - 1; j > 0; j--)
        {
            pState[j] = pState[j - 1];
        }
        pState[0] = pSrc[i];

        float acc = 0.0f;
        for (j = 0; j < numTaps; j++)
        {
            acc += pCoeffs[j] * pState[j];
        }
        pDst[i] = acc;
    }
}

void max30102_fir_init(void)
{
    fir_init_f32(&S_ir, FIR_NUM_TAPS, (float *)&firCoeffs32LP[0], &firStateF32_ir[0], blockSize);
    fir_init_f32(&S_red, FIR_NUM_TAPS, (float *)&firCoeffs32LP[0], &firStateF32_red[0], blockSize);
}

void ir_max30102_fir(float *input, float *output)
{
    fir_f32(&S_ir, input, output, blockSize);
}

void red_max30102_fir(float *input, float *output)
{
    fir_f32(&S_red, input, output, blockSize);
}
