#include "call.h"

#define HEARRATE_CACHE_NUMS     200
#define PPG_SAMPLE_INTERVAL_MS  20          /* 有效数据采样间隔(ms) = SMP_AVE个样本/SR */
#define HR_CALC_CONST           (60000 / PPG_SAMPLE_INTERVAL_MS)  /* 3000 */

static float s_ir_cache[HEARRATE_CACHE_NUMS];
static float s_ir_fir_cache[HEARRATE_CACHE_NUMS];
static uint16_t s_cache_index = 0;

static uint16_t s_hr_median_buf[7];
static uint8_t s_hr_median_cnt = 0;

uint8_t atk_max30102_write_byte(uint8_t reg, uint8_t data)
{
    iic_start();
    iic_send_byte(MAX30102_I2C_ADDR | 0x00);
    if (iic_wait_ack() != 0)
    {
        iic_stop();
        return 1;
    }
    iic_send_byte(reg);
    if (iic_wait_ack() != 0)
    {
        iic_stop();
        return 1;
    }
    iic_send_byte(data);
    if (iic_wait_ack() != 0)
    {
        iic_stop();
        return 1;
    }
    iic_stop();

    return 0;
}

uint8_t atk_max30102_read_byte(uint8_t reg)
{
    uint8_t temp = 0;

    iic_start();
    iic_send_byte(MAX30102_I2C_ADDR | 0x00);
    if (iic_wait_ack() != 0)
    {
        iic_stop();
        return 1;
    }
    iic_send_byte(reg);
    if (iic_wait_ack() != 0)
    {
        iic_stop();
        return 1;
    }

    iic_start();
    iic_send_byte(MAX30102_I2C_ADDR | 0x01);
    if (iic_wait_ack() != 0)
    {
        iic_stop();
        return 1;
    }
    temp = iic_read_byte(0);
    iic_stop();

    return temp;
}

int atk_max30102_read_nbytes(uint8_t reg, uint8_t *date, uint8_t len)
{
    uint8_t i;

    iic_start();
    iic_send_byte(MAX30102_I2C_ADDR | 0x00);
    if (iic_wait_ack() != 0)
    {
        iic_stop();
        return 1;
    }
    iic_send_byte(reg);
    if (iic_wait_ack() != 0)
    {
        iic_stop();
        return 1;
    }

    iic_start();
    iic_send_byte(MAX30102_I2C_ADDR | 0x01);
    if (iic_wait_ack() != 0)
    {
        iic_stop();
        return 1;
    }
    for (i = 0; i < len; i++)
    {
        date[i] = iic_read_byte((i == (len - 1)) ? 0 : 1);
    }
    iic_stop();

    return 0;
}

uint8_t atk_max30102_write_nbytes(uint8_t reg, uint8_t* data, uint8_t len)
{
    uint8_t i;

    iic_start();
    iic_send_byte(MAX30102_I2C_ADDR | 0x00);
    if (iic_wait_ack() != 0)
    {
        iic_stop();
        return 1;
    }
    iic_send_byte(reg);
    if (iic_wait_ack() != 0)
    {
        iic_stop();
        return 1;
    }
    for (i = 0; i < len; i++)
    {
        iic_send_byte(data[i]);
        if (iic_wait_ack() != 0)
        {
            iic_stop();
            return 1;
        }
    }
    iic_stop();

    return 0;
}

void atk_max30102_reset(void)
{
    atk_max30102_write_byte(MAX30102_MODE_CONFIG, 0x40);
    rt_thread_mdelay(10);
}

void atk_max30102_fifo_read(float *red_data, float *ir_data)
{
    uint8_t receive_data[6];
    atk_max30102_read_byte(MAX30102_INTR_STATUS_1);
    atk_max30102_read_byte(MAX30102_INTR_STATUS_2);

    atk_max30102_read_nbytes(MAX30102_FIFO_DATA, receive_data, 6);
    *red_data = ((receive_data[0] << 16 | receive_data[1] << 8 | receive_data[2]) & 0x03ffff);
    *ir_data = ((receive_data[3] << 16 | receive_data[4] << 8 | receive_data[5]) & 0x03ffff);
}

float atk_max30102_get_temp(void)
{
    float integer = 0.0f, fraction = 0.0f;

    atk_max30102_write_byte(MAX30102_TEMP_CONFIG, 0x01);

    integer = atk_max30102_read_byte(MAX30102_TEMP_INTR);
    fraction = atk_max30102_read_byte(MAX30102_TEMP_FRAC);

    if(integer < 0x80)
    {
        return (integer + fraction * 0.0625f);
    }
    else
    {
        integer -= 256;
        return (integer + fraction * 0.0625f);
    }
}

void atk_max30102_init(void)
{
    atk_max30102_reset();

    uint8_t part_id = atk_max30102_read_byte(MAX30102_PART_ID);
    //rt_kprintf("MAX30102 PART_ID: 0x%02X (expect 0x15)\r\n", part_id);

    atk_max30102_write_byte(MAX30102_INTR_ENABLE_1, 0xC0);
    atk_max30102_write_byte(MAX30102_INTR_ENABLE_2, 0x00);

    atk_max30102_write_byte(MAX30102_FIFO_WR_PTR, 0x00);
    atk_max30102_write_byte(MAX30102_OVF_COUNTER, 0x00);
    atk_max30102_write_byte(MAX30102_FIFO_RD_PTR, 0x00);

    atk_max30102_write_byte(MAX30102_FIFO_CONFIG, 0x5F);
    atk_max30102_write_byte(MAX30102_MODE_CONFIG, 0x03);
    atk_max30102_write_byte(MAX30102_SPO2_CONFIG, 0x2A);

    atk_max30102_write_byte(MAX30102_LED1_PA, 0x2F);
    atk_max30102_write_byte(MAX30102_LED2_PA, 0x2F);
    atk_max30102_write_byte(MAX30102_TEMP_CONFIG, 0x01);
    rt_thread_mdelay(100);

    atk_max30102_read_byte(MAX30102_INTR_STATUS_1);
    atk_max30102_read_byte(MAX30102_INTR_STATUS_2);

    // rt_kprintf("MODE_CONFIG:0x%02X SPO2_CFG:0x%02X FIFO_CFG:0x%02X\r\n",
    //     atk_max30102_read_byte(MAX30102_MODE_CONFIG),
    //     atk_max30102_read_byte(MAX30102_SPO2_CONFIG),
    //     atk_max30102_read_byte(MAX30102_FIFO_CONFIG));
    // rt_kprintf("LED1_PA:0x%02X LED2_PA:0x%02X\r\n",
    //     atk_max30102_read_byte(MAX30102_LED1_PA),
    //     atk_max30102_read_byte(MAX30102_LED2_PA));
}

/*******************************************************************************************/
uint16_t atk_max30102_get_heart(float *input_data, uint16_t cache_nums)
{
    /* 计算信号动态范围，用于幅度阈值 */
    float sig_max = input_data[0], sig_min = input_data[0];
    for (uint16_t i = 1; i < cache_nums; i++)
    {
        if (input_data[i] > sig_max) sig_max = input_data[i];
        if (input_data[i] < sig_min) sig_min = input_data[i];
    }
    float amplitude = sig_max - sig_min;
    float peak_threshold = sig_min + amplitude * 0.3f;

    int peaks[30];
    int num_peaks = 0;
    int last_peak = -12;

    /* min_distance = 12 → 240ms → 可检测最高 250 BPM */
    int min_distance = 12;

    for (int i = 1; i < cache_nums - 1; i++)
    {
        if (input_data[i] > input_data[i - 1] &&
            input_data[i] >= input_data[i + 1] &&
            input_data[i] > peak_threshold)
        {
            if (i - last_peak >= min_distance)
            {
                if (num_peaks < 30)
                {
                    peaks[num_peaks++] = i;
                    last_peak = i;
                }
            }
            else if (num_peaks > 0 && input_data[i] > input_data[peaks[num_peaks - 1]])
            {
                peaks[num_peaks - 1] = i;
                last_peak = i;
            }
        }
    }

    if (num_peaks < 2)
        return 0;

    int total_interval = 0;
    int valid_intervals = 0;
    for (int i = 1; i < num_peaks; i++)
    {
        int interval = peaks[i] - peaks[i - 1];

        /* 仅接受 12~100 样本间隔（对应 30~250 BPM） */
        if (interval >= 12 && interval <= 100)
        {
            total_interval += interval;
            valid_intervals++;
        }
    }

    if (valid_intervals == 0)
        return 0;

    int avg_interval = total_interval / valid_intervals;
    return (HR_CALC_CONST / avg_interval);
}

void hearrate_read()
{
    uint8_t wr_ptr = atk_max30102_read_byte(MAX30102_FIFO_WR_PTR) & 0x1F;
    uint8_t rd_ptr = atk_max30102_read_byte(MAX30102_FIFO_RD_PTR) & 0x1F;
    uint8_t num_available = (wr_ptr - rd_ptr) & 0x1F;

    for (uint8_t n = 0; n < num_available; n++)
    {
        if (s_cache_index >= HEARRATE_CACHE_NUMS)
            break;

        float ir_data, red_data;
        atk_max30102_fifo_read(&red_data, &ir_data);

        s_ir_cache[s_cache_index] = ir_data;

        ir_max30102_fir(&ir_data, &s_ir_fir_cache[s_cache_index]);
        s_cache_index++;
    }

    if (s_cache_index >= HEARRATE_CACHE_NUMS)
    {
        float ir_sum = 0;
        for (uint16_t i = 0; i < HEARRATE_CACHE_NUMS; i++)
            ir_sum += s_ir_cache[i];
        float ir_avg = ir_sum / HEARRATE_CACHE_NUMS;

        if (ir_avg < 50000)
        {
            USARTx_Printf(USART3, "HeaVal.val=0\xff\xff\xff");
            g_sensor_data.heart_rate = 0;
            s_cache_index = 0;
            return;
        }

        uint16_t heart_rate = atk_max30102_get_heart(s_ir_fir_cache, HEARRATE_CACHE_NUMS);

        /* 问题1：心率有效范围检查，覆盖30-250 BPM所有生理可能值 */
        if (heart_rate < 30 || heart_rate > 250)
            heart_rate = 0;

        /* EMA平滑：新值占1/4，历史值占3/4，大幅抑制跳变 */
        static uint16_t s_last_hr = 0;
        if (heart_rate != 0)
        {
            if (s_last_hr == 0)
                s_last_hr = heart_rate;
            else
                heart_rate = (heart_rate + s_last_hr * 3) / 4;
            s_last_hr = heart_rate;
        }
        else
        {
            s_last_hr = 0;
        }

        

        char dbg[32];
        sprintf(dbg, "HeaVal.val=%d\xff\xff\xff", (int)heart_rate);
        USARTx_Printf(USART3, dbg);

        /* 中值滤波：采集5次心率值，冒泡排序取中间值 */
        if (heart_rate != 0)
        {
            s_hr_median_buf[s_hr_median_cnt++] = heart_rate;

            if (s_hr_median_cnt >= 7)
            {
                s_hr_median_cnt = 0;

                for (uint8_t i = 0; i < 6; i++)
                {
                    for (uint8_t j = 0; j < 6 - i; j++)
                    {
                        if (s_hr_median_buf[j] > s_hr_median_buf[j + 1])
                        {
                            uint16_t temp = s_hr_median_buf[j];
                            s_hr_median_buf[j] = s_hr_median_buf[j + 1];
                            s_hr_median_buf[j + 1] = temp;
                        }
                    }
                }

                rt_thread_mdelay(500);
                uint16_t hr_median = s_hr_median_buf[4];
                g_sensor_data.heart_rate = hr_median;
                sprintf(dbg, "HeaVal.val=%d\xff\xff\xff", (int)hr_median);
                USARTx_Printf(USART3, dbg);
                hear=0;
            }
        }

        s_cache_index = 0;
    }
}