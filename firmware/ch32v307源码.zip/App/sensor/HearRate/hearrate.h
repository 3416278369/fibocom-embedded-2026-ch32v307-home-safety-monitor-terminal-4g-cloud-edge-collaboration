#ifndef _HEARRATE_H
#define _HEARRATE_H
#include "ch32v30x.h"

/******************************************************************************************/
/* 器件地址 */
#define MAX30102_I2C_ADDR               (0xAE)  /* 设备地址 写地址0xAE 读地址0xAF */

/* 寄存器地址 */
#define MAX30102_INTR_STATUS_1          0x00
#define MAX30102_INTR_STATUS_2          0x01
#define MAX30102_INTR_ENABLE_1          0x02
#define MAX30102_INTR_ENABLE_2          0x03

#define MAX30102_FIFO_WR_PTR            0x04
#define MAX30102_OVF_COUNTER            0x05
#define MAX30102_FIFO_RD_PTR            0x06
#define MAX30102_FIFO_DATA              0x07

#define MAX30102_FIFO_CONFIG            0x08
#define MAX30102_MODE_CONFIG            0x09
#define MAX30102_SPO2_CONFIG            0x0A
#define MAX30102_LED1_PA                0x0C
#define MAX30102_LED2_PA                0x0D

#define MAX30102_MULTI_LED_CTRL1        0x11
#define MAX30102_MULTI_LED_CTRL2        0x12

#define MAX30102_TEMP_INTR              0x1F
#define MAX30102_TEMP_FRAC              0x20
#define MAX30102_TEMP_CONFIG            0x21

#define MAX30102_PROX_INT_THRESH        0x30

#define MAX30102_REV_ID                 0xFE
#define MAX30102_PART_ID                0xFF

/******************************************************************************************/

/* 外部接口函数*/
float atk_max30102_get_temp(void);
void atk_max30102_init(void);
void atk_max30102_fifo_read(float *red_data, float *ir_data);
uint16_t atk_max30102_get_heart(float *input_data, uint16_t cache_nums);
void hearrate_read();
#endif
