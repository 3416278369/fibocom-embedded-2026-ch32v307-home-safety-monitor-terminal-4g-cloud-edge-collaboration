#include "call.h"

uint8_t atk_aht20_init(void)
{
    uint8_t command[2] = {0x08, 0x00};

    iic_init();

    rt_thread_mdelay(40);

    atk_aht20_write_nbytes(INIT, command, 2);

    rt_thread_mdelay(500);

    return atk_aht20_check();
}

uint8_t atk_aht20_read_status(void)
{
    uint8_t ret;

    atk_aht20_read_nbytes(&ret, 1);

    return ret;
}

uint8_t atk_aht20_check(void)
{
    if ((atk_aht20_read_status() & 0x08) == 0x08)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

void atk_aht20_read_data(float *temp, float *humi)
{
    uint32_t humi_data = 0, temp_data = 0;
    uint8_t raw_data[10];
    uint8_t command[2] = {0x33, 0x00};

    atk_aht20_write_nbytes(START_TEST, command, 2);
    rt_thread_mdelay(80);

    atk_aht20_read_nbytes(raw_data, 7);

    if ((raw_data[0] & 0x80) == 0x00)
    {
        humi_data = 0;
        humi_data = (humi_data | raw_data[1]) << 8;
        humi_data = (humi_data | raw_data[2]) << 8;
        humi_data = (humi_data | raw_data[3]);
        humi_data = humi_data >> 4;
        *humi = (float)humi_data * 100 / 1024 / 1024;

        temp_data = 0;
        temp_data = (temp_data | raw_data[3]) << 8;
        temp_data = (temp_data | raw_data[4]) << 8;
        temp_data = (temp_data | raw_data[5]);
        temp_data = temp_data & 0xfffff;
        *temp = (float)temp_data * 200 / 1024 / 1024 - 50;
    }
}

uint8_t atk_aht20_write_nbytes(uint8_t reg_addr, uint8_t *data, uint8_t len)
{
    iic_start();

    iic_send_byte(ATK_AHT20_IIC_ADDR | 0x00);
    if (iic_wait_ack() == 1)
    {
        iic_stop();
        return 1;
    }

    iic_send_byte(reg_addr);
    if (iic_wait_ack() == 1)
    {
        iic_stop();
        return 1;
    }

    for (uint16_t i = 0; i < len; i++)
    {
        iic_send_byte(data[i]);
        if (iic_wait_ack() == 1)
        {
            iic_stop();
            return 1;
        }
    }

    iic_stop();

    return 0;
}

uint8_t atk_aht20_read_nbytes(uint8_t *data, uint8_t len)
{
    iic_start();

    iic_send_byte(ATK_AHT20_IIC_ADDR | 0x01);
    if (iic_wait_ack() == 1)
    {
        iic_stop();
        return 1;
    }

    while (len)
    {
        *data = iic_read_byte((len > 1) ? 1 : 0);
        len--;
        data++;
    }

    iic_stop();

    return 0;
}

float temp = 0;
float humi = 0;
void temphumi_read()
{


    atk_aht20_read_data(&temp, &humi);
    
    g_sensor_data.temperature = temp;
    g_sensor_data.humidity    = humi;

    char dbg[32];
    sprintf(dbg, "tem.val=%d\xff\xff\xff", (int)temp);
    USARTx_Printf(USART3, dbg);

    sprintf(dbg, "Hum.val=%d\xff\xff\xff", (int)humi);
    USARTx_Printf(USART3, dbg);

}
