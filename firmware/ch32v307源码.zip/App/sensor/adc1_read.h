#ifndef __ADC1_READ_H
#define __ADC1_READ_H

#include "ch32v30x.h"

void light_read();
void fire_read();
void air_app();
void soil();
#endif