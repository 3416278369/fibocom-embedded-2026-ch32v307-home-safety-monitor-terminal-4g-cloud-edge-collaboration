#ifndef __L610_INIT_H
#define __L610_INIT_H

#include "call.h"

#define L610_RX_BUF_SIZE  512

void l6104g_init(void);
void l610_send(const char *str);
void l610_send_data(const uint8_t *data, uint16_t len);
void l610_init_check();

/* UART1 接收缓冲区（外部可访问） */
extern volatile uint16_t l610_rx_cnt;
extern uint8_t l610_rx_buffer[L610_RX_BUF_SIZE];

void l610_spear();
void l610_dianhuan();
void l610_dinwei();
void l610_rtc();
void l610_huawei();
void l610_huawei_flah();
int parse_rtc_response(const uint8_t *buf, uint16_t len, uint8_t *out);
void parse_hmrec_content(const uint8_t *buf, uint16_t len, uint8_t *data);
void parse_gtgis_response(const uint8_t *buf, uint16_t len);

/* 定位地址（去除空格后的 UTF-8 字节流） */
extern uint8_t l610_addr[128];
/* 地址中的汉字个数 */
extern uint16_t l610_addr_char_cnt;
#endif
