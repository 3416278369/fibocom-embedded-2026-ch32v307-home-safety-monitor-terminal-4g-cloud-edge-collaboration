#include "call.h"


/* 全局传感器数据结构体 */
volatile sensor_data_t g_sensor_data;
uint8_t contron = 0;//0-手动；1-自动；

/**
 * @brief 显示控制线程
 *        控制 SG90 舵机 0度 -> 90度 -> 180度 -> 90度 之间循环转动
 */
void app_disp(void *param)
{
    
    while(1)
    {
        gpio_write();
        rt_thread_mdelay(200);
        usart_hongwai();
        rt_thread_mdelay(100);
        suoji();
        rt_thread_mdelay(100);
        if(contron)
        {
            contron_zidong();//语音提醒与家电自动控制
            USARTx_Printf(USART3,"Ctr.auto.val=1\xff\xff\xff");
        }
        else
            USARTx_Printf(USART3,"Ctr.auto.val=0\xff\xff\xff");
            
        //SG90_SetAngle(0);
        rt_thread_mdelay(500);
    }
}

/**
 * @brief 传感器数据采集线程
 *        循环采集温湿度、光照、火焰、空气质量、土壤湿度等
 */
void sensor_read(void *param)
{
    while (1)
    {
        temphumi_read();    /* 温湿度采集 */
        rt_thread_mdelay(100);
        light_read();       /* 光照强度采集 */
        rt_thread_mdelay(50);
        fire_read();        /* 火焰采集 */
        rt_thread_mdelay(50);
        air_app();          /* 空气质量采集 */
        rt_thread_mdelay(50);
        soil();             /* 土壤湿度采集 */
        rt_thread_mdelay(50);
    }
}

/**
 * @brief 心率检测独立线程
 *        每100ms轮询一次MAX30102 FIFO，收集250个样本后计算一次心率
 */
uint8_t hear = 1;
void hr_thread_entry(void *param)
{
    char dbg[32];
    uint8_t lianjie_flag = 0;
    while (1)
    {
        if(lianjiecg == 1 && lianjie_flag == 0)
        {
            lianjie_flag = 1;
            USARTx_Printf(USART3,"online.val=1\xff\xff\xff");
        }
        rt_thread_mdelay(10);

        if(shuaidao[0] == 1)
            USARTx_Printf(USART3,"n0.val=1\xff\xff\xff");
        else
            USARTx_Printf(USART3,"n0.val=0\xff\xff\xff");
        rt_thread_mdelay(10);

        if(shuaidao[1] == 1)
            USARTx_Printf(USART3,"n1.val=1\xff\xff\xff");
        else
            USARTx_Printf(USART3,"n1.val=0\xff\xff\xff");

        rt_thread_mdelay(10);
        if(shuaidao[2] == 1)
            USARTx_Printf(USART3,"n2.val=1\xff\xff\xff");
        else
            USARTx_Printf(USART3,"n2.val=0\xff\xff\xff");
        rt_thread_mdelay(10);

        if(shuaidao[3] == 1){
            USARTx_Printf(USART3,"n3.val=1\xff\xff\xff");
            USARTx_Printf(USART3,"page War\xff\xff\xff");
        }
        else{
            USARTx_Printf(USART3,"n3.val=0\xff\xff\xff");
        }
        rt_thread_mdelay(10);


        if(g_sensor_data.heart_rate == 0)
            USARTx_Printf(USART3, "Hea.val=0\xff\xff\xff");
        else{
            sprintf(dbg, "HeaVal.val=%d\xff\xff\xff", g_sensor_data.heart_rate);
            USARTx_Printf(USART3, dbg);
        }
        sprintf(dbg, "O2Val.val=%d\xff\xff\xff", g_sensor_data.spo2);
        USARTx_Printf(USART3, dbg);
        rt_thread_mdelay(10);
        
    }
}


void L610_app(void *param)
{
    while(1)
    {
        
        l610_spear();
        rt_thread_mdelay(200);
        l610_dianhuan();
        rt_thread_mdelay(200);
        l610_dinwei();
        rt_thread_mdelay(200);
        l610_huawei();
        rt_thread_mdelay(200);
        l610_rtc();
        rt_thread_mdelay(200);
    }
}
