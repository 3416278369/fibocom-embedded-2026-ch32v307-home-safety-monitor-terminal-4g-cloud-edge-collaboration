#ifndef __I2C1_H
#define __I2C1_H

#include "ch32v30x.h"

#define IIC_SCL_GPIO_PORT               GPIOB
#define IIC_SCL_GPIO_PIN                GPIO_Pin_6
#define IIC_SCL_GPIO_CLK_ENABLE()       do{ RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); }while(0)

#define IIC_SDA_GPIO_PORT               GPIOB
#define IIC_SDA_GPIO_PIN                GPIO_Pin_7
#define IIC_SDA_GPIO_CLK_ENABLE()       do{ RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); }while(0)

#define IIC_SCL(x)        do{ x ? \
                              GPIO_SetBits(IIC_SCL_GPIO_PORT, IIC_SCL_GPIO_PIN) : \
                              GPIO_ResetBits(IIC_SCL_GPIO_PORT, IIC_SCL_GPIO_PIN); \
                          }while(0)

#define IIC_SDA(x)        do{ x ? \
                              GPIO_SetBits(IIC_SDA_GPIO_PORT, IIC_SDA_GPIO_PIN) : \
                              GPIO_ResetBits(IIC_SDA_GPIO_PORT, IIC_SDA_GPIO_PIN); \
                          }while(0)

#define IIC_READ_SDA     GPIO_ReadInputDataBit(IIC_SDA_GPIO_PORT, IIC_SDA_GPIO_PIN)

void iic_init(void);
void iic_start(void);
void iic_stop(void);
void iic_ack(void);
void iic_nack(void);
uint8_t iic_wait_ack(void);
void iic_send_byte(uint8_t txd);
uint8_t iic_read_byte(unsigned char ack);

#endif
