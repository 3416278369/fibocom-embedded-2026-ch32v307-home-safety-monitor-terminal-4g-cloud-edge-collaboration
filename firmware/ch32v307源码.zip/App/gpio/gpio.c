#include "gpio.h"

volatile uint8_t relay_1 = 0;
volatile uint8_t relay_2 = 0;
volatile uint8_t relay_3 = 0;
volatile uint8_t duoji_flag = 0;
void Relay_Init()
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};

    // ʹ�� GPIOA �� GPIOE ʱ��
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);

    // ���� PE6 Ϊ�������
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;         
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   // �������
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    // ��ѡ������ PE6 ��ʼ��ƽ��Ĭ�ϵ͵�ƽ��
    //GPIO_ResetBits(GPIOD, GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5);   // �����
    GPIO_SetBits(GPIOD, GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5);     // �����
}


void gpio_write()
{
    if(relay_1){
        GPIO_ResetBits(GPIOD,GPIO_Pin_3);
        USARTx_Printf(USART3,"Ctr.JDQ1.val=1\xff\xff\xff");
    }
    else{
        GPIO_SetBits(GPIOD,GPIO_Pin_3);// �����
        USARTx_Printf(USART3,"Ctr.JDQ1.val=0\xff\xff\xff");
    }
    if(relay_2){
        GPIO_ResetBits(GPIOD,GPIO_Pin_4);
        USARTx_Printf(USART3,"Ctr.JDQ2.val=1\xff\xff\xff");
    }
    else{
        GPIO_SetBits(GPIOD,GPIO_Pin_4);
        USARTx_Printf(USART3,"Ctr.JDQ2.val=0\xff\xff\xff");
    }
    if(relay_3){
        GPIO_ResetBits(GPIOD,GPIO_Pin_5);
        USARTx_Printf(USART3,"Ctr.JDQ3.val=1\xff\xff\xff");
    }
    else{
        GPIO_SetBits(GPIOD,GPIO_Pin_5);
        USARTx_Printf(USART3,"Ctr.JDQ3.val=0\xff\xff\xff");
    }
}

void suoji()//�������
{
    if(duoji_flag == 0){//0�ǹ�
        SG90_SetAngle(00);
        USARTx_Printf(USART3,"Ctr.DJ1.val=0\xff\xff\xff");
    }
    else{
        SG90_SetAngle(120);
        USARTx_Printf(USART3,"Ctr.DJ1.val=1\xff\xff\xff");
    }
}

uint8_t yuzhi[5] = {30,100,20,10,130};
//ͨ���ɼ��������Զ�����
void contron_zidong()
{
    if((uint8_t)temp >= yuzhi[0])//����
        relay_2 = 1;//�򿪼̵���2
    else
        relay_2 = 0;


    if(g_sensor_data.fire > 80)//�л���
    {
        if(yuying_flag[2] == 0)
            yuying = 2;//�����������
        duoji_flag = 1;
    }
    else{
        yuying_flag[2] = 0;
        if(g_sensor_data.air_quality<yuzhi[1])
            duoji_flag=0;
    }


    if(g_sensor_data.air_quality>yuzhi[1])//��������
        duoji_flag=1;
    else{
        if(g_sensor_data.fire < 50)
            duoji_flag =0;
    }


    if(g_sensor_data.soil < yuzhi[2] && g_sensor_data.soil > 0)//����ʪ��
        relay_3 = 1; 
    else if(g_sensor_data.soil > yuzhi[2] || g_sensor_data.soil == 0)//��ˮ�ӵ�10%
        relay_3 = 0;


    if(g_sensor_data.light<yuzhi[3])//����ǿ��
        relay_1 = 1;
    else
        relay_1=0;



    if(g_sensor_data.heart_rate>yuzhi[4])
    {
        if(dianhua_flag2 == 0)
            dianhua = 2;//������ϵ��1�绰
    }
    else
    {
        dianhua_flag2 = 0;
    }
}