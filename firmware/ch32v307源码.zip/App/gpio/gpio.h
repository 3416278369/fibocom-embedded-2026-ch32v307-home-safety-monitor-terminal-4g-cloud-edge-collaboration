#ifndef __GPIO_H
#define __GPIO_H

#include "call.h"

void Relay_Init();
void gpio_write();
void contron_zidong();
void zhuangtai();
void suoji();
#endif