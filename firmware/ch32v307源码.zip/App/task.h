#ifndef __TASK_H
#define __TASK_H

#include <rtthread.h>

void task_init(void);

#endif