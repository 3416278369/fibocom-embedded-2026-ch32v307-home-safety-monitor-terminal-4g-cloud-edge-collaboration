#!/usr/bin/env python3
"""
GB2312 -> Unicode mapping table generator
Covers all 6763 Chinese characters (row 16~87)
"""
import sys

def main():
    # GB2312 Chinese char area: row 16~87 (0xB0~0xF7), col 0xA1~0xFE (94 cols)
    rows_start = 16  # 0xB0
    rows_end = 87    # 0xF7
    cols_start = 0xA1
    cols_end = 0xFE
    num_rows = rows_end - rows_start + 1  # 72
    num_cols = cols_end - cols_start + 1  # 94

    # Store all Unicode codepoints in (row, col) order
    table = []
    for row in range(rows_start, rows_end + 1):
        for col in range(cols_start, cols_end + 1):
            hi = row + 0xA0  # GB2312 EUC hi byte
            lo = col         # GB2312 EUC lo byte
            gb_bytes = bytes([hi, lo])
            try:
                unicode_char = gb_bytes.decode('gbk')
                codepoint = ord(unicode_char)
            except UnicodeDecodeError:
                codepoint = 0x0000  # undefined char
            table.append(codepoint)

    with open('gb2312_unicode_table.h', 'w', encoding='ascii') as f:
        f.write("""/*
 * GB2312 -> Unicode mapping table (auto-generated)
 * Rows 16~87 (0xB0A1~0xF7FE), %d entries total
 * Usage: gb2312_unicode[(row-16)*94 + (col-0xA1)]
 *   where row=16~87 (0xB0~0xF7), col=0xA1~0xFE
 *   invalid/empty slots are 0x0000
 */
#ifndef GB2312_UNICODE_TABLE_H
#define GB2312_UNICODE_TABLE_H
#include <stdint.h>

#define GB2312_ROWS_START  16  /* 0xB0 */
#define GB2312_ROWS_END    87  /* 0xF7 */
#define GB2312_COLS_START  0xA1
#define GB2312_COLS_END    0xFE
#define GB2312_NUM_ROWS    72  /* 87-16+1 */
#define GB2312_NUM_COLS    94  /* 0xFE-0xA1+1 */

static const uint16_t gb2312_unicode_table[GB2312_NUM_ROWS][GB2312_NUM_COLS] = {
""" % (num_rows * num_cols))
        
        for row_idx in range(num_rows):
            if row_idx > 0 and row_idx % 8 == 0:
                f.write("\n")
            f.write("    { /* row %02d: 0x%02X */ " % (rows_start + row_idx, rows_start + row_idx + 0xA0))
            entries = []
            for col_idx in range(num_cols):
                idx = row_idx * num_cols + col_idx
                codepoint = table[idx]
                entries.append("0x%04X" % codepoint)
            f.write(", ".join(entries))
            f.write(" },\n")
        
        f.write("""};

#endif /* GB2312_UNICODE_TABLE_H */
""")

    print("Generated gb2312_unicode_table.h successfully!")

if __name__ == '__main__':
    main()
