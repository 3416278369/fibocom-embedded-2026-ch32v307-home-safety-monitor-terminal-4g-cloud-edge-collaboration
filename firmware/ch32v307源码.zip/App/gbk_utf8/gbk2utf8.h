#ifndef __GBK2UTF8_H
#define __GBK2UTF8_H

#include <stdint.h>

/**
 * @brief 将 GBK 编码的字符串转换为 UTF-8 编码
 * 
 * @param gbk_src  GBK 编码的输入字符串 (以 '\0' 结尾)
 * @param utf8_dst 输出的 UTF-8 字符串缓冲区
 * @param dst_size 输出缓冲区大小（字节数）
 * @return uint16_t 写入 utf8_dst 的实际字节数（不含结尾 '\0'）
 * 
 * 注意: 调用前需确保 utf8_dst 缓冲区足够大。
 *       对于全汉字的字符串，UTF-8 长度 ≈ GBK 长度 × 1.5
 *       建议 dst_size >= strlen(gbk_src) * 2
 */
uint16_t gbk_to_utf8(const uint8_t *gbk_src, uint8_t *utf8_dst, uint16_t dst_size);

#endif /* __GBK2UTF8_H */
