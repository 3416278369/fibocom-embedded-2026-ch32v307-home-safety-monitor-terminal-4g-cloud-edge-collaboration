#include <stddef.h>
#include "gbk2utf8.h"
#include "gb2312_unicode_table.h"

/**
 * @brief 将 Unicode 码点编码为 UTF-8 字节
 * 
 * @param codepoint Unicode 码点 (U+0000 ~ U+FFFF)
 * @param out       输出缓冲区（至少 3 字节）
 * @return uint8_t  写入的 UTF-8 字节数
 */
static uint8_t unicode_to_utf8(uint16_t codepoint, uint8_t *out)
{
    if (codepoint < 0x80) {
        /* 1字节: 0xxxxxxx */
        out[0] = (uint8_t)codepoint;
        return 1;
    } else if (codepoint < 0x800) {
        /* 2字节: 110xxxxx 10xxxxxx */
        out[0] = (uint8_t)(0xC0 | (codepoint >> 6));
        out[1] = (uint8_t)(0x80 | (codepoint & 0x3F));
        return 2;
    } else {
        /* 3字节: 1110xxxx 10xxxxxx 10xxxxxx */
        out[0] = (uint8_t)(0xE0 | (codepoint >> 12));
        out[1] = (uint8_t)(0x80 | ((codepoint >> 6) & 0x3F));
        out[2] = (uint8_t)(0x80 | (codepoint & 0x3F));
        return 3;
    }
}

uint16_t gbk_to_utf8(const uint8_t *gbk_src, uint8_t *utf8_dst, uint16_t dst_size)
{
    if (gbk_src == NULL || utf8_dst == NULL || dst_size == 0) {
        return 0;
    }

    uint16_t out_idx = 0;

    while (*gbk_src != '\0') {
        uint8_t c = *gbk_src;

        /* 情况1: ASCII 单字节 (0x00-0x7F)，直接透传 */
        if (c < 0x80) {
            if (out_idx + 1 >= dst_size) break;
            utf8_dst[out_idx++] = c;
            gbk_src++;
            continue;
        }

        /* 情况2: GBK/GB2312 双字节汉字 */
        if ((c >= 0x81 && c <= 0xFE) && *(gbk_src + 1) != '\0') {
            uint8_t hi = c;
            uint8_t lo = *(gbk_src + 1);

            /* 计算 GB2312 行号和列号 (1-based) */
            int row = (hi - 0xA0);     /* GB2312 区号, 1~94 */
            int col = (lo - 0xA0);     /* GB2312 位号, 1~94 */

            uint16_t unicode = 0;

            /* 只查汉字区: row 16~87 */
            if (row >= 16 && row <= 87) {
                int tbl_row = row - 16;
                int tbl_col = col - 1;  /* 表中列索引 0-based */
                if (tbl_col >= 0 && tbl_col < GB2312_NUM_COLS) {
                    unicode = gb2312_unicode_table[tbl_row][tbl_col];
                }
            }

            if (unicode != 0) {
                /* 将 Unicode 编码为 UTF-8 */
                uint8_t utf8_buf[4];
                uint8_t utf8_len = unicode_to_utf8(unicode, utf8_buf);
                if (out_idx + utf8_len >= dst_size) break;
                for (uint8_t i = 0; i < utf8_len; i++) {
                    utf8_dst[out_idx++] = utf8_buf[i];
                }
            }
            /* 跳过 GBK 双字节 */
            gbk_src += 2;
            continue;
        }

        /* 无法识别的字节，跳过 */
        gbk_src++;
    }

    /* 写入结尾 '\0' */
    if (out_idx < dst_size) {
        utf8_dst[out_idx] = '\0';
    }

    return out_idx;
}
