#ifndef __USART4_H
#define __USART4_H

#include "call.h"

void UART4_CFG(void);
void USARTx_SendByte(USART_TypeDef* pUSARTx, uint8_t data);
void USARTx_Printf(USART_TypeDef* pUSARTx ,const uint8_t *str);
void USARTx_SendArray(USART_TypeDef* pUSARTx, const uint8_t *data, uint16_t len);
void UART4_IRQHandler(void);
void usart4_tianwen51(const uint8_t *data, uint16_t len);
#endif
