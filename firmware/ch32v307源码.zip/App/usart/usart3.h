#ifndef __USART3_H
#define __USART3_H

#include "call.h"
#include <stdio.h>
#include <string.h>

void USARTx_CFG(void);
void USARTx_SendByte(USART_TypeDef* pUSARTx, uint8_t data);
void USARTx_Printf(USART_TypeDef* pUSARTx ,const uint8_t *str);
void USARTx_SendArray(USART_TypeDef* pUSARTx, const uint8_t *data, uint16_t len);
void USART3_IRQHandler(void);
void TAO_usart3(const uint8_t *data, uint16_t len);
#endif