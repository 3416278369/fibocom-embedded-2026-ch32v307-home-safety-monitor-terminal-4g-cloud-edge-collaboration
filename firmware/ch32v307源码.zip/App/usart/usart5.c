#include "usart5.h"

#define Rx_buf_size5 256
volatile uint16_t Rxcnt5 = 0;
uint8_t Rxbuffer5[Rx_buf_size5] = {0};

void UART5_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));

/* ========== UART5 初始化（PC12=TX, PD2=RX） ========== */
void UART5_CFG(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD, ENABLE);

    USART_DeInit(UART5);

    /* PC12 = TX (复用推挽输出) */
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOC, &GPIO_InitStructure);

    /* PD2 = RX (浮空输入) */
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    /* 串口参数：115200, 8N1 */
    USART_InitStructure.USART_BaudRate            = 115200;
    USART_InitStructure.USART_WordLength          = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits            = USART_StopBits_1;
    USART_InitStructure.USART_Parity              = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode                = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(UART5, &USART_InitStructure);

    /* 中断优先级配置 */
    NVIC_InitStructure.NVIC_IRQChannel                   = UART5_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    USART_Cmd(UART5, ENABLE);

    /* 使能接收中断 + 空闲中断 */
    USART_ITConfig(UART5, USART_IT_RXNE, ENABLE);
    USART_ITConfig(UART5, USART_IT_IDLE, ENABLE);
}

/* ========== UART5 中断处理 ========== */
void UART5_IRQHandler(void)
{
    uint8_t temp;

    /* 接收中断：逐个字节存到缓冲区 */
    if (USART_GetITStatus(UART5, USART_IT_RXNE) != RESET)
    {
        temp = (uint8_t)USART_ReceiveData(UART5);

        if (Rxcnt5 < Rx_buf_size5)
        {
            Rxbuffer5[Rxcnt5++] = temp;
        }
    }

    /* 空闲中断：一帧收完 */
    if (USART_GetITStatus(UART5, USART_IT_IDLE) != RESET)
    {
        (void)USART_ReceiveData(UART5);  /* 读数据清 IDLE 标志 */

        if (Rxcnt5 > 0)
        {
            USARTx_SendArray(UART5, Rxbuffer5,Rxcnt5);
            // usart_hongwai(Rxbuffer5, Rxcnt5);
            Rxcnt5 = 0;  /* 清缓冲区 */
        }
    }
}

uint8_t hongwai_flag = 0;

uint8_t hongai_send1[8] = {0x68,0x08,0x00,0xff,0x12,0x00,0x11,0x16};//
uint8_t hongai_send2[8] = {0x68,0x08,0x00,0xff,0x12,0x01,0x12,0x16};
void usart_hongwai()
{
    switch(hongwai_flag)
    {
        case 1:
            USARTx_SendArray(UART5, hongai_send1, 8);//红外关闭空调
            hongwai_flag = 0;
            USARTx_Printf(USART3,"Ctr.KT.val=0\xff\xff\xff");
        break;
        case 2:
            USARTx_SendArray(UART5, hongai_send2, 8);//红外打开空调
            hongwai_flag = 0;
            USARTx_Printf(USART3,"Ctr.KT.val=1\xff\xff\xff");
        break;
    }
}