#ifndef __USART6_H
#define __USART6_H

#include "call.h"

void UART6_CFG(void);
void UART6_IRQHandler(void);
void LAN_usart6(const uint8_t *data, uint16_t len);
#endif
