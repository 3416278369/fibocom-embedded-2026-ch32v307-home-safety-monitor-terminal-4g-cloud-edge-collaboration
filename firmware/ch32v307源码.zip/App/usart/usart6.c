#include "usart6.h"

#define Rx_buf_size6 256
volatile uint16_t Rxcnt6 = 0;
uint8_t Rxbuffer6[Rx_buf_size6] = {0};

void UART6_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));

/* ========== UART6 初始化（PC0=TX, PC1=RX） ========== */
void UART6_CFG(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART6, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

    USART_DeInit(UART6);

    /* PC0 = TX (复用推挽输出) */
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOC, &GPIO_InitStructure);

    /* PC1 = RX (浮空输入) */
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOC, &GPIO_InitStructure);

    /* 串口参数：115200, 8N1 */
    USART_InitStructure.USART_BaudRate            = 115200;
    USART_InitStructure.USART_WordLength          = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits            = USART_StopBits_1;
    USART_InitStructure.USART_Parity              = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode                = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(UART6, &USART_InitStructure);

    /* 中断优先级配置 */
    NVIC_InitStructure.NVIC_IRQChannel                   = UART6_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    USART_Cmd(UART6, ENABLE);

    /* 使能接收中断 + 空闲中断 */
    USART_ITConfig(UART6, USART_IT_RXNE, ENABLE);
    USART_ITConfig(UART6, USART_IT_IDLE, ENABLE);
}

/* ========== UART6 中断处理 ========== */
void UART6_IRQHandler(void)
{
    uint8_t temp;

    /* 接收中断：逐个字节存到缓冲区 */
    if (USART_GetITStatus(UART6, USART_IT_RXNE) != RESET)
    {
        temp = (uint8_t)USART_ReceiveData(UART6);

        if (Rxcnt6 < Rx_buf_size6)
        {
            Rxbuffer6[Rxcnt6++] = temp;
        }
    }

    /* 空闲中断：一帧收完 */
    if (USART_GetITStatus(UART6, USART_IT_IDLE) != RESET)
    {
        (void)USART_ReceiveData(UART6);  /* 读数据清 IDLE 标志 */

        if (Rxcnt6 > 0)
        {
            // USARTx_SendArray(UART6, Rxbuffer6, Rxcnt6);
            // USARTx_SendArray(UART5, Rxbuffer6,Rxcnt6);
            LAN_usart6(Rxbuffer6,Rxcnt6);
            Rxcnt6 = 0;  /* 清缓冲区 */
        }
    }
}


volatile uint8_t shuaidao[4] = {0,0,0,0};
volatile uint8_t lianjiecg = 0;//连接成功
void LAN_usart6(const uint8_t *data, uint16_t len)
{
    lianjiecg = 1;
    
    if(data[0] == '#' && data[len-1] == '#')
    {
        if(data[1] == '1')
            shuaidao[0] = 1;
        else 
            shuaidao[0] = 0;
        if(data[2] == '1')
            shuaidao[1] = 1;
        else 
            shuaidao[1] = 0;
        if(data[3] == '1')
            shuaidao[2] = 1;
        else 
            shuaidao[2] = 0;
        if(data[4] == '1')
        {
            shuaidao[3] = 1;
            if(yuying_flag[3]==0)
                yuying = 16;
        }
        else
        {
            shuaidao[3] = 0;
            yuying_flag[3] = 0;
        }
    }

    if(data[0] == '!' && data[len-1] == '!')
    {
        g_sensor_data.heart_rate = (data[1]-'0')*100 + (data[2]-'0')*10 + (data[3]-'0');
        g_sensor_data.spo2 = (data[4]-'0')*10 + (data[5]-'0');

    }
}