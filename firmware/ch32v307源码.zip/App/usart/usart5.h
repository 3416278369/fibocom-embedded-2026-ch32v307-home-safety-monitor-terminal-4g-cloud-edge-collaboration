#ifndef __USART5_H
#define __USART5_H

#include "call.h"

void UART5_CFG(void);
void USARTx_SendByte(USART_TypeDef* pUSARTx, uint8_t data);
void USARTx_Printf(USART_TypeDef* pUSARTx ,const uint8_t *str);
void USARTx_SendArray(USART_TypeDef* pUSARTx, const uint8_t *data, uint16_t len);
void UART5_IRQHandler(void);
void usart_hongwai();
#endif
