#include "usart4.h"

#define Rx_buf_size4 256
volatile uint16_t Rxcnt4 = 0;
uint8_t Rxbuffer4[Rx_buf_size4] = {0};

void UART4_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));

/* ========== UART4 初始化（PC10=TX, PC11=RX） ========== */
void UART4_CFG(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

    USART_DeInit(UART4);

    /* PC10 = TX (复用推挽输出) */
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOC, &GPIO_InitStructure);

    /* PC11 = RX (浮空输入) */
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOC, &GPIO_InitStructure);

    /* 串口参数：115200, 8N1 */
    USART_InitStructure.USART_BaudRate            = 115200;
    USART_InitStructure.USART_WordLength          = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits            = USART_StopBits_1;
    USART_InitStructure.USART_Parity              = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode                = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(UART4, &USART_InitStructure);

    /* 中断优先级配置 */
    NVIC_InitStructure.NVIC_IRQChannel                   = UART4_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    USART_Cmd(UART4, ENABLE);

    /* 使能接收中断 + 空闲中断 */
    USART_ITConfig(UART4, USART_IT_RXNE, ENABLE);
    USART_ITConfig(UART4, USART_IT_IDLE, ENABLE);
}

/* ========== UART4 中断处理 ========== */
void UART4_IRQHandler(void)
{
    uint8_t temp;

    /* 接收中断：逐个字节存到缓冲区 */
    if (USART_GetITStatus(UART4, USART_IT_RXNE) != RESET)
    {
        temp = (uint8_t)USART_ReceiveData(UART4);

        if (Rxcnt4 < Rx_buf_size4)
        {
            Rxbuffer4[Rxcnt4++] = temp;
        }
    }

    /* 空闲中断：一帧收完 */
    if (USART_GetITStatus(UART4, USART_IT_IDLE) != RESET)
    {
        (void)USART_ReceiveData(UART4);  /* 读数据清 IDLE 标志 */

        if (Rxcnt4 > 0)
        {
            USARTx_SendArray(USART3, Rxbuffer4, Rxcnt4);
            usart4_tianwen51(Rxbuffer4, Rxcnt4);
            Rxcnt4 = 0;  /* 清缓冲区 */
        }
    }
}

void usart4_tianwen51(const uint8_t *data, uint16_t len)
{
    if(data[0] == 0x30 && data[len-1]==0x40)
    {
        if(data[1] == 0x31 && data[2] == 0x30)//关闭继电器1
        {
            relay_1 = 0;
            yuying = 4;
        }
            
        if(data[1] == 0x31 && data[2] == 0x31)
        {
            relay_1 = 1;
            yuying = 3;
        }
        if(data[1] == 0x32 && data[2] == 0x30)//关闭继电器2
        {
            relay_2 = 0;
            yuying = 6;
        }
        if(data[1] == 0x32 && data[2] == 0x31)
        {
            relay_2 = 1;
            yuying = 5;
        }
        if(data[1] == 0x33 && data[2] == 0x30)//关闭继电器3
        {
            relay_3 = 0;
            yuying = 8;
        }
        if(data[1] == 0x33 && data[2] == 0x31)
        {
            relay_3 = 1;
            yuying = 7;
        }
        if(data[1] == 0x34 && data[2] == 0x30)//关闭空调
        {
            hongwai_flag = 1;
            yuying = 13;
        }
        if(data[1] == 0x34 && data[2] == 0x31)//打开空调
        {
            hongwai_flag = 2;
            yuying = 12;
        }
        if(data[1] == 0x35 && data[2] == 0x31)//测量心率
            hear = 1;
        if(data[1] == 0x36 && data[2] == 0x31)//打开设备自动运行
        {
            contron = 1;
            yuying = 14;
        }   
        if(data[1] == 0x36 && data[2] == 0x30)//关闭设备自动运行
        {
            contron = 0;
            yuying = 15;
        }
        if(data[1] == 0x37 && data[2] == 0x31)//拨打联系人1
            dianhua = 2;
        if(data[1] == 0x37 && data[2] == 0x32)//拨打联系人2
            dianhua = 3;
        if(data[1] == 0x37 && data[2] == 0x30)//挂断
            dianhua = 10;
        if(data[1] == 0x38 && data[2] == 0x31)//打开窗户
        {
            duoji_flag = 1;
            yuying = 9;
        }
        if(data[1] == 0x38 && data[2] == 0x30)//关闭窗户
        {
            duoji_flag = 0;
            yuying = 11;
        }
        if(data[1] == 0x39 && data[2] == 0x31)//现在几点了
        {
            rtc =1;
        }
    }
}
