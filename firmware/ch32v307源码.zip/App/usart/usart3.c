#include "usart3.h"

#define Rx_buf_size3 256
volatile uint16_t Rxcnt3 = 0;
uint8_t Rxbuffer3[Rx_buf_size3] = {0};

void USART3_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));

/* ========== UART3 初始化（PB10=TX, PB11=RX） ========== */
void USARTx_CFG(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

    USART_DeInit(USART3);

    /* PB10 = TX (复用推挽输出) */
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    /* PB11 = RX (浮空输入) */
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    /* 串口参数：115200, 8N1 */
    USART_InitStructure.USART_BaudRate            = 115200;
    USART_InitStructure.USART_WordLength          = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits            = USART_StopBits_1;
    USART_InitStructure.USART_Parity              = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode                = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(USART3, &USART_InitStructure);

    /* 中断优先级配置 */
    NVIC_InitStructure.NVIC_IRQChannel                   = USART3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    USART_Cmd(USART3, ENABLE);

    /* 使能接收中断 + 空闲中断 */
    USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);
    USART_ITConfig(USART3, USART_IT_IDLE, ENABLE);
}

/* ========== 发送单字节 ========== */
void USARTx_SendByte(USART_TypeDef* pUSARTx, uint8_t data)
{
    USART_SendData(pUSARTx, data);
    while (USART_GetFlagStatus(pUSARTx, USART_FLAG_TXE) == RESET);
}

/* ========== 发送字符串 ========== */
void USARTx_Printf(USART_TypeDef* pUSARTx, const uint8_t *str)
{
    while (*str != '\0')
    {
        while (USART_GetFlagStatus(pUSARTx, USART_FLAG_TXE) == RESET);
        USART_SendData(pUSARTx, (uint8_t)*str++);
    }
}

/* ========== 发送指定长度数据 ========== */
void USARTx_SendArray(USART_TypeDef* pUSARTx, const uint8_t *data, uint16_t len)
{
    if (data == NULL || pUSARTx == NULL || len == 0) return;

    for (uint16_t i = 0; i < len; i++)
    {
        USARTx_SendByte(pUSARTx, data[i]);
    }
    while (USART_GetFlagStatus(pUSARTx, USART_FLAG_TC) == RESET);  /* 等待发送完成 */
}

/* ========== UART3 中断处理 ========== */
/* 电脑发数据 → UART3 收到 → 原样回发给电脑（回路测试） */
void USART3_IRQHandler(void)
{
    uint8_t temp;

    /* 1. 接收中断：逐个字节存到缓冲区 */
    if (USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)
    {
        temp = (uint8_t)USART_ReceiveData(USART3);

        if (Rxcnt3 < Rx_buf_size3)
        {
            Rxbuffer3[Rxcnt3++] = temp;
        }
    }

    /* 2. 空闲中断：一帧收完，原样回发给电脑 */
    if (USART_GetITStatus(USART3, USART_IT_IDLE) != RESET)
    {
        (void)USART_ReceiveData(USART3);  /* 读数据清 IDLE 标志 */

        if (Rxcnt3 > 0)
        {
            //USARTx_SendArray(USART3, Rxbuffer3, Rxcnt3);  /* 回发给电脑 */
            TAO_usart3(Rxbuffer3,Rxcnt3);

            Rxcnt3 = 0;  /* 清缓冲区 */
        }
    }
}

void TAO_usart3(const uint8_t *data, uint16_t len)
{
    uint8_t i;
    if(data[0] == 0x21 &&data[len-1] == 0x23)
    {
        if(data[1] == 0x30)
        {
            for(i = 0;i<11;i++)
            {
                lianxiren_0[i]=data[i+2];//存入号码
            }//存好后置位打电话的标志位
            lianxiren_0[11] = 0x3b;
            dianhua = 1;
        }
        if(data[1] == 0x31)
        {
            for(i = 0;i<11;i++)
            {
                lianxiren_1[i]=data[i+2];//存入号码
            }//存好后置位打电话的标志位
            dianhua = 2;
        }
        if(data[1] == 0x32)
        {
            for(i = 0;i<11;i++)
            {
                lianxiren_2[i]=data[i+2];//存入号码
            }//存好后置位打电话的标志位
            dianhua = 3;
        }
        if(data[1] == 0xff)
            dianhua = 10;

    }

    if(data[0] == 0xf8 && data[len-1] == 0x8f)
    {
        if(data[1]==0xaa&&data[2]==0x00)//
        {
            contron = 0;
            yuying = 15;
        }
        if(data[1]==0xaa&&data[2]==0x01)//开启手动
        {
            contron = 1;
            yuying = 14;
        }
        if(data[1]==0x01&&data[2]==0x00)//关闭继电器1
        {
            relay_1 = 0;
            yuying = 4;
        }
        if(data[1]==0x01&&data[2]==0x01)//
        {
            yuying = 3;
            relay_1 = 1;
        }
        if(data[1]==0x02&&data[2]==0x00)//关闭继电器2
        {
            relay_2 = 0;
            yuying = 6;
        }
            
        if(data[1]==0x02&&data[2]==0x01)//
        {
            relay_2 = 1;
            yuying = 5;
        }
        if(data[1]==0x03&&data[2]==0x00)//关闭继电器3
        {
            relay_3 = 0;
            yuying = 8;
        }
        if(data[1]==0x03&&data[2]==0x01)//
        {
            relay_3 = 1;
            yuying = 7;
        }
        if(data[1]==0x04&&data[2]==0x00)//舵机
        {
            duoji_flag = 0;
            yuying = 11;
        }
        if(data[1]==0x04&&data[2]==0x01)//
        {
            duoji_flag = 1;
            yuying = 9;
        }
        if(data[1]==0x05&&data[2]==0x00)//打开空调
        {
            hongwai_flag = 1;
            yuying = 13;
        }
        if(data[1]==0x05&&data[2]==0x01)//
        {
            hongwai_flag = 2;
            yuying = 12;
        }
    }

    if(data[0] == 0xf9 && data[len-1] == 0x9f)
    {
        for(i = 0;i < 5;i++)
        {
            yuzhi[i] = data[i+1];
        }
    }
}
